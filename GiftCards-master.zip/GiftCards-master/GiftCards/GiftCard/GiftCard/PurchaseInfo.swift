//
//  PurchaseInfo.swift
//  GiftCard
//
//  Created by Nisarg Vora on 8/19/16.
//  Copyright © 2016 Nisarg Vora. All rights reserved.
//

import Foundation

class PurchaseInfo {
    var giftCardDetails : GiftCard?
    var rewardsAmount : String?
    var giftCardAmount : String?
    var rewardsSelected : Bool?
    var emailSelected : Bool?
}
