//
//  GiftDetailsViewController.swift
//  GiftCard
//
//  Created by Nisarg Vora on 8/18/16.
//  Copyright © 2016 Nisarg Vora. All rights reserved.
//

import UIKit

class GiftDetailsViewController: UIViewController {
    
    @IBOutlet weak var giftCardImage: UIImageView!
    @IBOutlet weak var giftCardImageBackgroundView: UIView!
    @IBOutlet weak var giftCardDetailsBackgroundView: UIView!
    @IBOutlet weak var purchaseButton: UIButton!
    
    var giftCardDetails : GiftCard?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        setupGiftCardImage(giftCardDetails!.image_url!)
        

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func setupGiftCardImage(urlString : String) {
        let imgURL: NSURL = NSURL(string: urlString)!
        let request: NSURLRequest = NSURLRequest(URL: imgURL)
        
        NSURLSession.sharedSession().dataTaskWithRequest(request, completionHandler: { data, response, error in
            guard let data = data where error == nil else { return }
            dispatch_async(dispatch_get_main_queue(), {
                self.giftCardImage.image = UIImage(data: data)
            })
        }).resume()
    }
    
    func setupUI() {
        self.giftCardDetailsBackgroundView.layer.borderColor = UIColor(red: 230/255, green: 230/255, blue: 230/255, alpha: 1.0).CGColor
        self.giftCardDetailsBackgroundView.layer.borderWidth = 1
        
        self.purchaseButton.layer.backgroundColor = UIColor(red:0.16, green:0.7, blue:0.9, alpha:1).CGColor
        self.purchaseButton.layer.borderWidth = 1
        self.purchaseButton.layer.borderColor = UIColor(red:0, green:0.62, blue:0.87, alpha:1).CGColor
        applyLineEffect(giftCardDetailsBackgroundView)
        
    }
    
    func applyLineEffect(givenView: UIView) {
        let width = givenView.frame.size.width
        let height = givenView.frame.size.height
        
        let lineWidth = CGFloat(7)
        let lineHeight = CGFloat(-5)
        let yInitial = height-lineHeight + 50
        
        let zigZagPath = UIBezierPath()
        zigZagPath.moveToPoint(CGPointMake(0, 0))
        zigZagPath.addLineToPoint(CGPointMake(0, yInitial))
        
        var slope = -1
        var x = CGFloat(0)
        var i = 0
        while x < width {
            x = lineWidth * CGFloat(i)
            let p = lineHeight * CGFloat(slope)
            let y = yInitial + p
            let point = CGPointMake(x, y)
            zigZagPath.addLineToPoint(point)
            slope = slope*(-1)
            i += 1
        }
        zigZagPath.addLineToPoint(CGPointMake(width, 0))
        
        let shapeLayer = CAShapeLayer()
        shapeLayer.path = zigZagPath.CGPath
        givenView.layer.mask = shapeLayer
        givenView.layer.shadowColor = UIColor.blackColor().CGColor
        givenView.layer.shadowOffset = CGSize(width: 10, height: 20)
        givenView.layer.shadowOpacity = 1
        givenView.layer.shadowRadius = 26
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
