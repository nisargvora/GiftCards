//
//  GiftCardCell.swift
//  GiftCard
//
//  Created by Vora, Nisarg on 8/18/16.
//  Copyright © 2016 Nisarg Vora. All rights reserved.
//

import UIKit

class GiftCardCell: UICollectionViewCell {
    @IBOutlet weak var cardImageView: UIImageView!
    
    @IBOutlet weak var cardName: UILabel!
}
