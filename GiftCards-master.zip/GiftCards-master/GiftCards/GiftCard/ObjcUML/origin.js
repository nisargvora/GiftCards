   var dependencies =
{"links":[{"source":"AppDelegate","dest":"AnyObject"}],"source_files_count":2,"links_count":1}